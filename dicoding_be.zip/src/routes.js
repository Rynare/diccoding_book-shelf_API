import { path } from "@hapi/joi/lib/errors.js"
import { book } from "./handler.js"

const routes = [
    {
        method: "POST",
        path: "/books",
        handler: book.addBook,
    },
    {
        method: "GET",
        path: "/books",
        handler: book.showAll,
    },
    {
        method: "GET",
        path: "/books/{bookId}",
        handler: book.showDetail,
    },
    {
        method: "PUT",
        path: "/books/{bookId}",
        handler: book.updateBook,
    },
    {
        method: "DELETE",
        path: "/books/{bookId}",
        handler: book.deleteBook,
    },
]

export {routes}